package cs321.patriotbuddy;

/**
 * Created by mr.banskota on 3/28/18.
 */

public interface Messagable {

    public void sendMessage(String message);
    public void receiveMessage(String message);
}
