package cs321.patriotbuddy;

/**
 * Created by mr.banskota on 3/29/18.
 */

public class Group implements Messagable {

    public String name = "";

    public void sendMessage(String message){


    }

    public void receiveMessage(String message){

    }

    public boolean isPrivate()
    {

        return false;
    }
}
